package ee.walkpet.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Forest = Color(0xFF10251C)
private val Green = Color(0xFF24B832)
private val Pale = Color(0xFFF2F5F1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WalkPetApp() }
    }
}

@Composable
fun WalkPetApp() {
    var role by remember { mutableStateOf("Владелец") }
    var page by remember { mutableStateOf("home") }
    var urgent by remember { mutableStateOf(true) }
    var duration by remember { mutableStateOf("60 минут") }
    var booked by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Pale, surface = Color.White)) {
        Scaffold(containerColor = Pale, bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(page == "home", { page = "home" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Главная") })
                NavigationBarItem(page == "orders", { page = "orders" }, icon = { Icon(Icons.Default.ListAlt, null) }, label = { Text("Заказы") })
                NavigationBarItem(page == "profile", { page = "profile" }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Профиль") })
            }
        }) { padding ->
            when (page) {
                "home" -> Home(role, { role = it }, { urgent = true; page = "booking" }, { urgent = false; page = "booking" }, padding)
                "booking" -> Booking(urgent, duration, { duration = it }, { booked = true; page = "orders" }, { page = "home" }, padding)
                "orders" -> Orders(booked, padding)
                else -> Profile(role, { role = it }, padding)
            }
        }
    }
}

@Composable
fun Home(role: String, setRole: (String) -> Unit, urgent: () -> Unit, plan: () -> Unit, padding: PaddingValues) {
    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Text("WalkPet 🐾", color = Forest, fontSize = 29.sp, fontWeight = FontWeight.Bold)
            Text("Прогулки с питомцами рядом с тобой", color = Color.DarkGray)
        }
        item {
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Forest)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Привет!", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Выберите режим", color = Color.White.copy(alpha = .8f))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(role == "Владелец", { setRole("Владелец") }, label = { Text("Я владелец") })
                        FilterChip(role == "Выгульщик", { setRole("Выгульщик") }, label = { Text("Я выгульщик") })
                    }
                }
            }
        }
        item {
            Text(if (role == "Владелец") "Найти помощь для питомца" else "Начать зарабатывать", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Forest)
            Button(onClick = urgent, modifier = Modifier.fillMaxWidth().height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = Green), shape = RoundedCornerShape(15.dp)) {
                Icon(Icons.Default.Bolt, null); Spacer(Modifier.width(8.dp)); Text(if (role == "Владелец") "Нужен выгульщик сейчас" else "Посмотреть заказы")
            }
            OutlinedButton(onClick = plan, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Icon(Icons.Default.CalendarMonth, null); Spacer(Modifier.width(8.dp)); Text("Запланировать прогулку")
            }
        }
        item {
            Text("Рядом с вами", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Forest)
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Box(Modifier.fillMaxWidth().height(130.dp).background(Color(0xFFE1EBDD), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Map, null, tint = Forest, modifier = Modifier.size(34.dp))
                            Text("Демо-карта Таллинна")
                            Text("Подключение GPS будет добавлено отдельно", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                    Walker("Анна", "4,9 ★ · рядом", "от 5 €")
                    Divider()
                    Walker("Сергей", "4,8 ★ · рядом", "от 5 €")
                }
            }
        }
    }
}
@Composable fun Walker(name: String, info: String, price: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.AccountCircle, null, tint = Green, modifier = Modifier.size(38.dp))
        Column(Modifier.weight(1f).padding(start = 10.dp)) { Text(name, fontWeight = FontWeight.Bold); Text(info, color = Color.Gray, fontSize = 12.sp) }
        Text(price, color = Green, fontWeight = FontWeight.Bold)
    }
}
@Composable
fun Booking(urgent: Boolean, duration: String, setDuration: (String) -> Unit, submit: () -> Unit, back: () -> Unit, padding: PaddingValues) {
    Column(Modifier.fillMaxSize().padding(padding).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, null) }; Text("Новый заказ", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Forest) }
        Card { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Pets, null, tint = Green, modifier = Modifier.size(34.dp)); Column(Modifier.padding(start = 12.dp)) { Text("Мой питомец", fontWeight = FontWeight.Bold); Text("Профиль питомца — демо") } } }
        Text("Длительность", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("30 минут", "60 минут", "90 минут").forEach { FilterChip(duration == it, { setDuration(it) }, label = { Text(it) }) } }
        Text("Когда?", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Card { Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(if (urgent) Icons.Default.Bolt else Icons.Default.CalendarMonth, null, tint = Green); Text(if (urgent) "Как можно скорее" else "Предварительное бронирование", Modifier.padding(start = 10.dp)) } }
        Text("Предварительная цена: 5–10 €", color = Forest, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        Button(onClick = submit, modifier = Modifier.fillMaxWidth().height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Найти выгульщика") }
    }
}
@Composable fun Orders(booked: Boolean, padding: PaddingValues) {
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
        Text("Мои заказы", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Forest); Spacer(Modifier.height(16.dp))
        if (booked) Card { Column(Modifier.padding(18.dp)) { Text("Заявка создана · демо", fontWeight = FontWeight.Bold); Text("Прогулка ожидает подтверждения."); Text("Реальная отправка заказа требует серверной части.", color = Color.Gray) } }
        else Text("Пока заказов нет. Создайте первую прогулку на главной.")
    }
}
@Composable fun Profile(role: String, setRole: (String) -> Unit, padding: PaddingValues) {
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Профиль", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Forest)
        Text("Текущий режим: $role")
        OutlinedButton(onClick = { setRole(if (role == "Владелец") "Выгульщик" else "Владелец") }) { Text("Переключить режим") }
        Text("WalkPet · версия 0.1.0", color = Color.Gray)
    }
}
